# -*- coding: utf-8 -*-
"""
Created on Sat Apr 12 17:48:43 2025

@author: madar
"""

# Step 1: Import libraries
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Step 2: Load the data
file_path = "C:/Users/madar/OneDrive/Desktop/Border_Crossing_Entry_Data.csv"
df = pd.read_csv(file_path)

print(df.isnull().sum())

# Step 3: Explore the data
print("First few rows of the data:")
print(df.head())

print("\nData Summary:")
print(df.info())

# Step 4: Clean the data
# Convert Date to datetime format
df['Date'] = pd.to_datetime(df['Date'])


#Border crossing trends over time
plt.figure(figsize=(14, 6))
sns.lineplot(data=df, x='Date', y='Value', marker='o')
plt.title('Border Crossing Trends Over Time', fontsize=16)
plt.xlabel('Date')
plt.ylabel('Total Crossings')
plt.grid(True)
plt.tight_layout()
plt.show()


#Crossing trends by mesasure
plt.figure(figsize=(14, 6))
sns.lineplot(data=df, x='Date', y='Value', hue='Measure')
plt.title('Border Crossing Trends by Measure Over Time', fontsize=16)
plt.xlabel('Date')
plt.ylabel('Total Crossings')
plt.legend(title='Measure')
plt.grid(True)
plt.tight_layout()
plt.show()





# Visualize the comparison
plt.figure(figsize=(10, 6))
sns.barplot(data=df, x='Value', y='Measure', palette='Set2')
plt.title('Comparison of Means of Transportation', fontsize=16)
plt.xlabel('Total Crossings')
plt.ylabel('Mode of Transportation')
plt.tight_layout()
plt.show()






#  Visualize the total crossings by border
plt.figure(figsize=(8, 5))
sns.barplot(data=df, x='Border', y='Value', palette='viridis')
plt.title('Total Border Crossings by Border', fontsize=14)
plt.xlabel('Border')
plt.ylabel('Total Crossings')
plt.xticks(rotation=45)
plt.tight_layout()
plt.show()




#top 10 most popular ports of entry
plt.figure(figsize=(12, 6))
sns.barplot(data=df, x='Value', y='Port Name', palette='mako')
plt.title('Top 10 Most Popular Ports of Entry', fontsize=16)
plt.xlabel('Total Crossings')
plt.ylabel('Port Name')
plt.tight_layout()
plt.show()